
# TaskMaster

TaskMaster is a full-stack task management system built with Node.js, Express, MongoDB, and a vanilla HTML/CSS/JavaScript frontend.

## Features
- User Registration & Login (JWT Authentication)
- Create, Read, Update, Delete (CRUD) tasks
- Filter tasks by priority or due date
- Search tasks by keywords
- Deployed with Fly.io (Backend) and Vercel/Netlify (Frontend)

## Backend Setup
```bash
cd backend
npm install
npm run dev
```

### Environment Variables
Create a `.env` file in the `backend` folder:
```
PORT=5000
MONGO_URI=your_mongodb_connection_string
JWT_SECRET=your_jwt_secret
```

## Frontend Setup
Simply open `frontend/index.html` directly in your browser or deploy to Netlify/Vercel for hosting.

## Deployment
- Backend: Fly.io
- Frontend: Vercel or Netlify
